package ar.centro8.java.curso.trabajo_practico_2.interfaz;

public interface IVehiculo {
    public void mostrarVehiculo();
} 