package ar.centro8.java.curso.trabajo_practico_2.entidades;

import java.text.NumberFormat;
import java.util.Locale;

import ar.centro8.java.curso.trabajo_practico_2.interfaz.IVehiculo;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public abstract class Vehiculo implements IVehiculo, Comparable<Vehiculo> {
    private final String marca;
    private final String modelo;
    private final Double precio;
    
    
    public String formatearPrecio() {
    final NumberFormat formato = NumberFormat.getNumberInstance(new Locale("es", "AR"));
    formato.setMinimumFractionDigits(2); 
    formato.setMaximumFractionDigits(2);
    return "$" + formato.format(precio);
    }
    
    public abstract void mostrarVehiculo(); // Método de la interface
    
    @Override
    public int compareTo(Vehiculo o) {
        String thisVehiculo = this.getMarca() + this.getModelo() + this.getPrecio();
        String oVehiculo = o.getMarca() + o.getModelo() + o.getPrecio();
        return thisVehiculo.compareTo(oVehiculo);
    }

    
    
}


