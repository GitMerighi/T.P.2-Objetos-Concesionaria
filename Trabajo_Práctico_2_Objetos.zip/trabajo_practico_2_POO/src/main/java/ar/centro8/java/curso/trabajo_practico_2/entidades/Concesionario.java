package ar.centro8.java.curso.trabajo_practico_2.entidades;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.TreeSet;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Concesionario {
    private List<Vehiculo> vehiculos;
    
    public Concesionario() {
        this.vehiculos = new ArrayList<>();
    }

    public void mostrarLista(){
        vehiculos.forEach(v -> v.mostrarVehiculo());
    }

    public void separador(){
        System.out.println("\n=============================\n");
    }


    public void agregarVehiculo (){
        Auto auto1 = new Auto("Peugeot", "206", 200000.0, 4);
        Auto auto2 = new Auto("Peugeot", "208", 250000.0, 5);
        Moto moto1 = new Moto("Honda", "Titan", 60000.0, "125c");
        Moto moto2 = new Moto("Yamaha", "YBR", 80500.50, "160c");
        vehiculos.add(auto1);
        vehiculos.add(moto1);
        vehiculos.add(auto2);
        vehiculos.add(moto2);
    }

    public void masCaro(){
        Double precioMax = vehiculos
            .stream()
            .max(Comparator.comparingDouble(Vehiculo::getPrecio))
            .get()
            .getPrecio();
            
        vehiculos   
                .stream()
                .filter(v->v.getPrecio().equals(precioMax))
                .forEach(v-> System.out.println("Vehículo más caro: " + v.getMarca() + " " + v.getModelo()));
    }

    public void masBarato(){
        Double precioMin = vehiculos
            .stream()
            .min(Comparator.comparingDouble(Vehiculo::getPrecio))
            .get()
            .getPrecio();
        
        vehiculos
                .stream()
                .filter(v->v.getPrecio().equals(precioMin))
                .forEach(v-> System.out.println("Vehículo más barato: " + v.getMarca() + " " + v.getModelo()));
    }

    public void vehiculoConY(){
        Vehiculo contengaLetra = vehiculos
                .stream()
                .filter(v->v.getModelo().toLowerCase().contains("y"))
                .findFirst()
                .get();
        System.out.println("Vehículo que contiene en el modelo la letra 'Y': " + contengaLetra.getMarca() + " " + contengaLetra.getModelo() + " " + contengaLetra.formatearPrecio());
    }

    public void ordenMayorMenor(){
        System.out.println("Vehículos ordenados por precio de mayor a menor:");
        vehiculos
                .stream()
                .sorted(Comparator.comparing(Vehiculo::getPrecio).reversed())
                .forEach(v -> System.out.println(v.getMarca() + " " + v.getModelo()));
    }

    public void ordenNatural(){
        System.out.println("Vehículos ordenados por orden natural (marca, modelo, precio): ");
        TreeSet<Vehiculo> setVehiculo;
        setVehiculo = new TreeSet<>();
        setVehiculo.addAll(vehiculos);
        setVehiculo.forEach(System.out::println);
    }

}
