package ar.centro8.java.curso.trabajo_practico_2.Test;

import ar.centro8.java.curso.trabajo_practico_2.entidades.Concesionario;


public class TestConcesionaria {
    public static void main(String[] args) {
        Concesionario concesionario1 = new Concesionario();
        concesionario1.agregarVehiculo();
        concesionario1.mostrarLista();
        concesionario1.separador();

        concesionario1.masCaro();
        concesionario1.masBarato();
        concesionario1.vehiculoConY();
        concesionario1.separador();

        concesionario1.ordenMayorMenor();
        concesionario1.separador();

        concesionario1.ordenNatural();
    }
}


